package com.urbanisation_si.microservices_assure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesAssureApplicationTests {

	@Test
	void contextLoads() {
	}

}
