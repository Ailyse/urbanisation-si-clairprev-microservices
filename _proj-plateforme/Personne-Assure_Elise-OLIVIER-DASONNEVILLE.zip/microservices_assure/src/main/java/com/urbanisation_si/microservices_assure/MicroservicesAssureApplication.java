package com.urbanisation_si.microservices_assure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesAssureApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesAssureApplication.class, args);
	}

}
